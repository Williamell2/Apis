# API de Gerenciamento de Tarefas


## Como executar

1. npm install*
2. node src/app.js

## Endpoints
1 GET/lista todas as tarefas
2 POST/criar nova tarefa
3 GET/ Buscar tarefa por id 
4 PUT/ Atualizar uma tarefa 
5 PATCH/ Marcar uma tarefa como concluída 
6 GET/ filtrar tarefas concluída 
7 DELETE/ Deleta tarefa